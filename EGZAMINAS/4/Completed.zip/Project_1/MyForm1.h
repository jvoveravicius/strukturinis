#pragma once
#include <windows.h>

static double getTime() {
	LARGE_INTEGER freq, val;
	QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&val);
	return (double)val.QuadPart / (double)freq.QuadPart;
}

namespace Project_1 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::Threading;

	/// <summary>
	/// Summary for MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{
		// ==================================== Threading
		delegate void StringArgReturningVoidDelegate(String^ text);

		Thread^ cpuTimerThread;
		
		//tried to use this example:
		//https://docs.microsoft.com/en-us/dotnet/framework/winforms/controls/how-to-make-thread-safe-calls-to-windows-forms-controls

		void ThreadProcSafe()
		{
			double d0 = getTime();

			while (true)
			{
				double timeInMilliseconds = 1000 * (getTime() - d0);
				int seconds = (int)(timeInMilliseconds / 1000) % 60;
				int minutes = (int)(timeInMilliseconds / (1000 * 60)) % 60;
				int hours = (int)(timeInMilliseconds / (1000 * 60 * 60)) % 24;
				String^ s = String::Format("{0}:{1}:{2}", hours, minutes, seconds);
				this->SetText(s);
			}
		}

		void SetText(String^ text)
		{
			if (this->label1->InvokeRequired)
			{
				StringArgReturningVoidDelegate^ d =
				gcnew StringArgReturningVoidDelegate(this, &MyForm::SetText);
				this->Invoke(d, gcnew array<Object^> { text });
			}
			else
			{
				this->label1->Text = text;
			}
		}
		// ==================================== Threading

	public:
		MyForm(void)
		{
			InitializeComponent();
			// ==================================== Threading
			this->cpuTimerThread = gcnew Thread(gcnew ThreadStart(this, &MyForm::ThreadProcSafe));
			this->cpuTimerThread->Start();
			// ==================================== Threading
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	public: System::Windows::Forms::Label^  label1;
	protected:



	protected:

	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AccessibleName = L"";
			this->label1->AutoSize = true;
			this->label1->Font = (gcnew System::Drawing::Font(L"Microsoft Sans Serif", 40, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(0)));
			this->label1->Location = System::Drawing::Point(70, 45);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(173, 63);
			this->label1->TabIndex = 0;
			this->label1->Text = L"label1";
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(296, 157);
			this->Controls->Add(this->label1);
			this->Name = L"MyForm";
			this->Text = L"CPU Clock";
			this->Load += gcnew System::EventHandler(this, &MyForm::MyForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
	private: System::Void MyForm_Load(System::Object^  sender, System::EventArgs^  e) {
	}
};
}
